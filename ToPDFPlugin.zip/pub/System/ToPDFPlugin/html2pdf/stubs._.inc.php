<?php

function _($text) {
  return $text;
}

?>