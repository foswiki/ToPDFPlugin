<?php

class CSSValue {
  /**
   * Check if some subproperties should be inherited;
   * inherit calculated values from the parent box
   */
  function doInherit($state) {
    // Generic method; do nothing
  }

  function clearDefaultFlags(&$state) {
    // Generic method; do nothing
  }
}

?>