<?php

// Last assigned box unique identifier. 
$GLOBALS['g_box_uid'] = 0;
$GLOBALS['__html_box_id_map'] = array();

?>